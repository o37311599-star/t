# FrameForge

FrameForge is a local HTML-to-video production tool. The React/TypeScript editor uploads HTML files or ZIP projects, shows the project in a sandboxed Chromium preview, captures browser frames on the backend, and encodes those frames into an H.264 MP4 with FFmpeg. Render progress is delivered over Socket.IO.

## Requirements

- Node.js 20 or newer and npm
- The project includes an FFmpeg binary for the current platform; an external FFmpeg with `libx264` on `PATH` is also supported via `FFMPEG_PATH`
- Chromium installed through Playwright
- Windows, macOS, or Linux

## Install and run

From this directory:

```sh
npm install
npm run install:browser
```

Optionally install or verify a system FFmpeg:

```sh
ffmpeg -version
ffmpeg -hide_banner -encoders
```

On Windows, an external FFmpeg can be installed with `winget install Gyan.FFmpeg`. The bundled binary is used by default; set `FFMPEG_PATH` only to override it.

Start both development servers:

```sh
npm run dev
```

Open <http://localhost:5173>. The API listens on port 4174. To build and run the compiled local app on one port, use `npm run build` followed by `npm start`, then open <http://localhost:4174>.

Copy `.env.example` to `.env` and set values in your shell before starting the server. `PORT`, `MAX_UPLOAD_MB`, `MAX_CONCURRENT_RENDERS`, `JOB_RETENTION_HOURS`, `FFMPEG_PATH`, `PLAYWRIGHT_EXECUTABLE_PATH`, and `PLAYWRIGHT_BROWSERS_PATH` are shown for deployment configuration. At present, the app enforces one render at a time and uses the upload size and FFmpeg settings; job retention, custom browser executable, and concurrency values are not dynamically enforced. The backend's data folder defaults to `./.frameforge-data`; set `FRAMEFORGE_DATA` to change it.

## Using the editor

1. Open **Studio**, then upload an `.html`, `.htm`, or `.zip` project. ZIP folders and relative paths are preserved. If the archive has multiple HTML files, choose the entry file in the project list.
2. Preview the page in the editor. The preview is a real Chromium page in a sandboxed iframe. Preview transport commands control CSS and Web Animations API effects through an injected bridge. Arbitrary `requestAnimationFrame` loops continue on their own clock and cannot be paused or rewound universally.
3. Choose output resolution, frame rate, quality, start time, and duration. The render maximum is 300 seconds. Start time delays capture before its first frame.
4. Click **Render video**. The backend captures individual Chromium frames at the configured cadence, then invokes FFmpeg. The job page reports backend stages and frame progress. Download is available after FFmpeg exits successfully.

## Rendering behavior and known limits

The render uses real-time capture. It takes a browser screenshot for each frame and waits until the next frame's scheduled wall-clock time. CSS, JavaScript, SVG, canvas, and WebGL content can appear in captures when Chromium supports the content, but the renderer does not advance arbitrary animation clocks deterministically. If a page's animation is not tied to elapsed time, depends on user interaction, or runs slower than the requested capture cadence, frames may repeat or timing may differ from a deterministic export. Use a project-specific animation duration that matches the export duration. The page audio track is not captured, and audio upload/mixing is not implemented. MP4 transparency is not supported.

The preview transport sends commands to a small bridge injected into the sandboxed page. Play, pause, restart, and seek control CSS and Web Animations API effects. Arbitrary `requestAnimationFrame` loops continue on their own clock and cannot be paused or rewound universally. Export starts at the configured start time and honors the requested capture duration. H.264 quality options select CRF/preset pairs: Draft 30/ultrafast, Standard 24/fast, High 20/medium, and Ultra 16/slow. H.265 and WebM are not implemented.

## Architecture

```text
src/                 React editor, landing page, projects and settings
server/index.ts      Express API, uploads, preview files, render jobs and Socket.IO progress
./.frameforge-data/
  projects/<id>/      Extracted source project trees
  jobs/<id>/          Frame sequence during a render and final output.mp4
```

## Local security notes

Uploaded HTML is untrusted executable code. The editor preview uses an iframe sandbox without `allow-same-origin`; the API rejects requests carrying the sandbox's opaque `null` origin. Projects and jobs use random IDs, ZIP entries are checked against path traversal, upload sizes are limited, Chromium runs headlessly without its sandbox for local compatibility, and render jobs are serialized. This is intended for a single-user local workstation. It is not a hardened multi-user service: remote network access by HTML pages is not blocked, data directories have normal OS permissions, and a production deployment should use isolated worker containers, explicit network egress controls, authentication/ownership checks, disk quotas, and retention cleanup.

## Troubleshooting

- **Chromium missing:** run `npm run install:browser`.
- **FFmpeg unavailable / encoder failed:** run `ffmpeg -version`, confirm `libx264` appears in `ffmpeg -encoders`, then set `FFMPEG_PATH` if needed.
- **ZIP has no entry:** choose a ZIP that contains an `.html` or `.htm` file. The app chooses `index.html` when present and otherwise the first HTML file; select among detected files in the project list.
- **Missing asset or remote font:** confirm the path/case is correct and that the page can access the network resource. Local relative paths remain under their original project folders.
- **Slow or repeated frames:** lower output resolution/FPS or simplify the animation. Real-time browser rendering is CPU-bound and can't guarantee deterministic timing for every page.
- **Large render:** capture frames are written to disk and removed after successful encoding; ensure enough free disk space for the frames and final video.

## API

- `GET /api/health` — service status
- `POST /api/projects` — upload HTML/ZIP as multipart field `file`
- `GET /api/projects/:id` — project metadata
- `PATCH /api/projects/:id/entry` — select an HTML entry (`{ "entry": "index.html" }`)
- `POST /api/render` — create render `{ projectId, width, height, fps, duration, start, quality, filename }`
- `GET /api/jobs/:id` — job status
- `GET /api/jobs/:id/download` — completed MP4
- `DELETE /api/jobs/:id` — cancel a running render

## Scope

The delivered local application provides the core upload, project asset listing, browser preview, selectable output settings, real browser frame capture, FFmpeg encoding, progress, cancel, and download flow. Projects are held on disk and project recents use browser local storage. Accounts, database-backed project lifecycle (rename/duplicate/delete/reopen across server restarts), dedicated audio, editable animation clock, job retry, thumbnails, H.265/WebM and production worker isolation remain future work; the interface does not claim those features are active.
